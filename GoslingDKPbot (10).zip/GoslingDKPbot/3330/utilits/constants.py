# utilits/constants.py
import os

# List of allowed channel IDs
ALLOWED_CHANNELS = [1286846764649021461, 1232906500528144436]

# Updated date
UPDATE_DATE = '27.09.24'

# Path to the database
DATABASE = os.getenv('DATABASE')
