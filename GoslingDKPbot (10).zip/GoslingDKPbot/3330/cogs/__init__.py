# cogs/__init__.py
